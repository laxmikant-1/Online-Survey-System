package survey;

import java.sql.SQLException;

public class Main {
	public static void main(String args[]) throws Exception {
		Login login = new Login();
		login.loginView();
	}
}